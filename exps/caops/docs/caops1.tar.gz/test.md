# Test run 

1. COAPS configuration
2. They are not using any forcing datasets

# salinity 
59691812427d5eb53eebd3e90260eaa5483e1ba3


# SST 
![](SST/surface_sst0.png)
![](SST/surface_sst47.png)

![](out.gif)


# SSH

- sea surface height
  
![](SSH/ssh_0.png)
![](SSH/ssh_47.png)
![](SSH.gif)


# vertical 

- 41 levels ( HYCOM)

## salinity 

![](salin_1.png)
![](salin_2.png)
